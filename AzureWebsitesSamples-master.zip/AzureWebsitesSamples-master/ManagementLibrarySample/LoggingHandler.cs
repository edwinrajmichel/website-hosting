﻿using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace ManagementLibrarySample
{
    // LoggingHandler derived from http://stackoverflow.com/questions/12300458/web-api-audit-logging
    public class LoggingHandler : DelegatingHandler
    {
        public LoggingHandler(HttpMessageHandler innerHandler)
            : base(innerHandler)
        {
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            Console.WriteLine("*********************");
            Console.Write("Request: ");
            Console.WriteLine("{0} {1}", request.Method, request.RequestUri);
            if (request.Content != null)
            {
                Console.WriteLine(await request.Content.ReadAsStringAsync());
            }
            Console.WriteLine();

            HttpResponseMessage response = await base.SendAsync(request, cancellationToken);

            Console.Write("Response: ");
            Console.WriteLine("{0} {1}", (int)response.StatusCode, response.ReasonPhrase);
            if (response.Content != null)
            {
                Console.WriteLine(await response.Content.ReadAsStringAsync());
            }
            Console.WriteLine();

            return response;
        }
    }
}
